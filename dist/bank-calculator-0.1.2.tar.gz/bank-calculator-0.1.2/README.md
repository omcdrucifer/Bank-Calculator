# Bank Calculator

Project 1 - Python Terminal Game

11-24-24

This is a savings and loan calculator that I started on my own but am now incorporating into a portfolio 
project for Codecademy CS certification

This code will be fleshed out to be a more interactive application that is used in a terminal.

Most recent iteration now has a title screen and a welcome message that explains what the application
is about. The underlying logic is unchanged as I wrote the print statements as functions in a separate file
to be imported into the main file wherein I just had to create print objects and print functions.

11-25-24

At this point I think I've done as much as I can with this little program. It probably went a bit faster than the course designers intended. But being that I had a week head start and decided it fit the criteria of the assignment, I decided to just build on what I already had.

11-25-24 Repo Update

I am renaming this repo so that instead of focusing on one portfolio project, I can use it to store them all. Renaming to "Codecademy Portfolio Projects". 

As such, I am restructuring the folder system on the tree so that each one is labeled for the appropriate project.

12-3-24

I am renaming the repo again. I decided that it was going to be necessary to learn how to ship actual packages. That being said, I figured trying to store multiple, possibly unreleated, packages in a single repo. So I will be re-dedicating this one to the bank calculator project, and starting new repos for subsequent projects.

Somehow 'import logging' got removed. Re-added
